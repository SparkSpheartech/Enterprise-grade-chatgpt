from fastapi import FastAPI, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from database import engine, Base
from routers import api, graph, agents
import uvicorn

# Create tables (introspection simulation)
Base.metadata.create_all(bind=engine)

app = FastAPI(title="GigaPulse API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os

# ... existing code ...

app.include_router(api.router, prefix="/api")
app.include_router(graph.router, prefix="/api/graph")
app.include_router(agents.router, prefix="/api/agents")

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    while True:
        data = await websocket.receive_text()
        await websocket.send_text(f"Message text was: {data}")

# Serve Static Files
# Get absolute path to frontend directory
current_dir = os.path.dirname(os.path.abspath(__file__))
frontend_dir = os.path.join(current_dir, "..", "frontend")

app.mount("/static", StaticFiles(directory=frontend_dir), name="static")

@app.get("/")
async def read_root():
    """Serve the login page"""
    return FileResponse(os.path.join(frontend_dir, "login.html"))

@app.get("/app")
async def read_app():
    """Serve the main application"""
    return FileResponse(os.path.join(frontend_dir, "index.html"))

if __name__ == "__main__":
    # Seed data on startup
    from seed_data import seed_data
    try:
        seed_data()
        print("Database seeded successfully!")
    except Exception as e:
        print(f"Error seeding data: {e}")

    # Open browser automatically
    import webbrowser
    webbrowser.open("http://localhost:8000")
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
