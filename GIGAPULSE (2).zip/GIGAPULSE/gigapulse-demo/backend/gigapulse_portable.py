"""
GigaPulse Portable Launcher
Standalone version that bundles all dependencies
"""
import sys
import os
import webbrowser
import time
import threading
from pathlib import Path

# Set up paths for bundled application
if getattr(sys, 'frozen', False):
    # Running as compiled executable
    application_path = sys._MEIPASS
else:
    # Running as script
    application_path = os.path.dirname(os.path.abspath(__file__))

# Add application path to sys.path
sys.path.insert(0, application_path)

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import uvicorn
from database import engine, Base
from routers import api, graph, agents

# Create tables
Base.metadata.create_all(bind=engine)

app = FastAPI(title="GigaPulse API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Determine frontend directory
if getattr(sys, 'frozen', False):
    # Bundled application
    frontend_dir = os.path.join(sys._MEIPASS, "frontend")
else:
    # Development
    frontend_dir = os.path.join(application_path, "..", "frontend")

# Include routers
app.include_router(api.router, prefix="/api")
app.include_router(graph.router, prefix="/api/graph")
app.include_router(agents.router, prefix="/api/agents")

# Serve static files
app.mount("/static", StaticFiles(directory=frontend_dir), name="static")

@app.get("/")
async def read_root():
    """Serve the login page"""
    return FileResponse(os.path.join(frontend_dir, "login.html"))

@app.get("/app")
async def read_app():
    """Serve the main application"""
    return FileResponse(os.path.join(frontend_dir, "index.html"))

def open_browser():
    """Open browser after a short delay"""
    time.sleep(2)
    webbrowser.open("http://localhost:8000")

if __name__ == "__main__":
    print("="*50)
    print("  GigaPulse Network Operations Intelligence")
    print("="*50)
    print()
    print("Starting server...")
    print("Application will open in your browser shortly...")
    print()
    print("Press Ctrl+C to stop the server")
    print("="*50)
    
    # Seed data on startup
    try:
        from seed_data import seed_data
        seed_data()
        print("✓ Database initialized successfully!")
    except Exception as e:
        print(f"⚠ Database initialization: {e}")
    
    # Start browser in background thread
    threading.Thread(target=open_browser, daemon=True).start()
    
    # Run server
    uvicorn.run(
        app, 
        host="0.0.0.0", 
        port=8000, 
        log_level="info"
    )
