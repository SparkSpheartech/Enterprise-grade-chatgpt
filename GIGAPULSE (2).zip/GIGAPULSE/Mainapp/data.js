// Synthetic Data based on README schema

const rawData = {
    outageEvents: [
        { id: "OUT-2024-CA-001", type: "Outage", label: "Gigabit Fiber Res", customers: 2847, duration: "8.5h", status: "Resolved" },
        { id: "OUT-2024-CA-002", type: "Outage", label: "Business Fiber 500", customers: 412, duration: "8.5h", status: "Resolved" },
        { id: "OUT-2024-CA-003", type: "Outage", label: "Internal Network", customers: 23, duration: "8.5h", status: "Resolved" },
        { id: "OUT-2024-CA-004", type: "Outage", label: "Gigabit Fiber Res Sec", customers: 1523, duration: "5.25h", status: "Resolved" },
        { id: "OUT-2024-CA-005", type: "Outage", label: "Business Fiber 1Gig Sec", customers: 186, duration: "5.25h", status: "Resolved" }
    ],
    infrastructure: [
        { id: "FBR-CA-SNFC-TRUNK-A01", type: "Infrastructure", label: "Main Trunk A01", status: "DAMAGED", capacity: "144 fibers" },
        { id: "FBR-CA-SNFC-TRUNK-A02", type: "Infrastructure", label: "Secondary Trunk A02", status: "DAMAGED", capacity: "96 fibers" },
        { id: "SP-2847", type: "Infrastructure", label: "Splice Point 2847", status: "DESTROYED" },
        { id: "SP-1523", type: "Infrastructure", label: "Splice Point 1523", status: "DAMAGED" }
    ],
    facilities: [
        { id: "SNFCCA01", type: "Facility", label: "SF Central Office", status: "AFFECTED" },
        { id: "SNFCCA02", type: "Facility", label: "SF Secondary CO", status: "AFFECTED" }
    ],
    equipment: [
        { id: "OLT-01", type: "Equipment", label: "OLT Device 01", location: "SNFCCA01" },
        { id: "OLT-02", type: "Equipment", label: "OLT Device 02", location: "SNFCCA01" },
        { id: "RTR-CORE-01", type: "Equipment", label: "Core Router 01", location: "SNFCCA01" }
    ],
    crews: [
        { id: "CREW-CA-NOR-012", type: "Crew", label: "Crew 012 (Thomas)", size: 4, task: "144-strand splice" },
        { id: "CREW-CA-NOR-013", type: "Crew", label: "Crew 013 (Sarah)", size: 3, task: "96-strand splice" },
        { id: "CREW-CA-NOR-014", type: "Crew", label: "Crew 014 (Marcus)", size: 2, task: "Conduit repair" }
    ],
    noc: [
        { id: "NOC-OPR-003", type: "NOC", label: "David Chen (Lead)", role: "Incident Commander" },
        { id: "ENG-CA-001", type: "NOC", label: "Robert Martinez", role: "GPON Specialist" },
        { id: "ENG-CA-003", type: "NOC", label: "Michael Patel", role: "Core Network Specialist" }
    ],
    agents: [
        { id: "AGT-001", type: "Agent", label: "Agent Sarah", role: "Tech Support" },
        { id: "AGT-002", type: "Agent", label: "Agent Mike", role: "Business Support" },
        { id: "SUP-001", type: "Supervisor", label: "Sup. Michael Torres", role: "Residential Lead" }
    ],
    construction: [
        { id: "CONST-001", type: "Construction", label: "CalTrans Construction Inc", liability: "Under Investigation", cost: "$284,500" }
    ],
    timeline: [
        { id: "TL-0615", type: "Timeline", label: "06:15 - Outage Start", description: "Fiber severed" },
        { id: "TL-0617", type: "Timeline", label: "06:17 - NOC Response", description: "Ticket Created" },
        { id: "TL-0715", type: "Timeline", label: "07:15 - Crew Arrival", description: "First crew on site" },
        { id: "TL-1445", type: "Timeline", label: "14:45 - Restoration", description: "Primary trunk restored" }
    ],
    interactions: [
        { id: "INT-001", type: "Interaction", label: "Call #2849", channel: "Phone", nps: 4 },
        { id: "INT-002", type: "Interaction", label: "Chat #9932", channel: "Chat", nps: 5 }
    ],
    customers: [
        { id: "CUST-001", type: "Customer", label: "Res. Customer 1", segment: "Residential" },
        { id: "CUST-002", type: "Customer", label: "Res. Customer 2", segment: "Residential" },
        { id: "CUST-003", type: "Customer", label: "Res. Customer 3", segment: "Residential" },
        { id: "BUS-001", type: "Customer", label: "Tech Corp HQ", segment: "Business" },
        { id: "BUS-002", type: "Customer", label: "Local Cafe", segment: "Business" },
        { id: "INT-001", type: "Customer", label: "Internal IT", segment: "Internal" }
    ]
};

// Define relationships (Source -> Target)
const relationships = [
    // Construction to Outage (Root Cause)
    { source: "CONST-001", target: "OUT-2024-CA-001", label: "Caused" },
    { source: "CONST-001", target: "FBR-CA-SNFC-TRUNK-A01", label: "Damaged" },

    // Outage to Infra
    { source: "OUT-2024-CA-001", target: "FBR-CA-SNFC-TRUNK-A01", label: "Involves" },
    { source: "OUT-2024-CA-002", target: "FBR-CA-SNFC-TRUNK-A01", label: "Involves" },
    { source: "OUT-2024-CA-004", target: "FBR-CA-SNFC-TRUNK-A02", label: "Involves" },

    // Infra to Infra
    { source: "FBR-CA-SNFC-TRUNK-A01", target: "SP-2847", label: "Contains" },
    { source: "FBR-CA-SNFC-TRUNK-A02", target: "SP-1523", label: "Contains" },
    { source: "FBR-CA-SNFC-TRUNK-A01", target: "SNFCCA01", label: "Connects To" },
    { source: "SNFCCA01", target: "SNFCCA02", label: "Linked CO" },

    // Equipment to Location
    { source: "OLT-01", target: "SNFCCA01", label: "Located At" },
    { source: "OLT-02", target: "SNFCCA01", label: "Located At" },
    { source: "RTR-CORE-01", target: "SNFCCA01", label: "Located At" },
    { source: "OLT-01", target: "FBR-CA-SNFC-TRUNK-A01", label: "Terminates" },

    // Crews to Infra
    { source: "CREW-CA-NOR-012", target: "SP-2847", label: "Repairing" },
    { source: "CREW-CA-NOR-013", target: "SP-1523", label: "Repairing" },
    { source: "CREW-CA-NOR-014", target: "SP-2847", label: "Assisting" },

    // NOC to Outage
    { source: "NOC-OPR-003", target: "OUT-2024-CA-001", label: "Managing" },
    { source: "ENG-CA-001", target: "FBR-CA-SNFC-TRUNK-A01", label: "Analyzing" },

    // Agents & Supervisors
    { source: "AGT-001", target: "SUP-001", label: "Reports To" },
    { source: "AGT-002", target: "SUP-001", label: "Reports To" },

    // Interactions
    { source: "CUST-001", target: "INT-001", label: "Initiated" },
    { source: "INT-001", target: "AGT-001", label: "Handled By" },
    { source: "BUS-001", target: "INT-002", label: "Initiated" },
    { source: "INT-002", target: "AGT-002", label: "Handled By" },

    // Timeline Links
    { source: "TL-0615", target: "OUT-2024-CA-001", label: "Start" },
    { source: "TL-0617", target: "NOC-OPR-003", label: "Action" },
    { source: "TL-0715", target: "CREW-CA-NOR-012", label: "Arrival" },
    { source: "TL-1445", target: "OUT-2024-CA-001", label: "Resolved" },

    // Customers to Outage
    { source: "CUST-001", target: "OUT-2024-CA-001", label: "Affected By" },
    { source: "CUST-002", target: "OUT-2024-CA-001", label: "Affected By" },
    { source: "CUST-003", target: "OUT-2024-CA-004", label: "Affected By" },
    { source: "BUS-001", target: "OUT-2024-CA-002", label: "Affected By" },
    { source: "BUS-002", target: "OUT-2024-CA-005", label: "Affected By" },
    { source: "INT-001", target: "OUT-2024-CA-003", label: "Affected By" }
];

// Transform to Graph Data Format
function getGraphData() {
    const nodes = [
        ...rawData.outageEvents.map(d => ({ ...d, group: 'outage', val: 25 })),
        ...rawData.infrastructure.map(d => ({ ...d, group: 'infra', val: 15 })),
        ...rawData.facilities.map(d => ({ ...d, group: 'facility', val: 18 })),
        ...rawData.equipment.map(d => ({ ...d, group: 'equipment', val: 12 })),
        ...rawData.crews.map(d => ({ ...d, group: 'crew', val: 10 })),
        ...rawData.noc.map(d => ({ ...d, group: 'noc', val: 10 })),
        ...rawData.agents.map(d => ({ ...d, group: 'agent', val: 8 })),
        ...rawData.construction.map(d => ({ ...d, group: 'construction', val: 20 })),
        ...rawData.timeline.map(d => ({ ...d, group: 'timeline', val: 5 })),
        ...rawData.interactions.map(d => ({ ...d, group: 'interaction', val: 4 })),
        ...rawData.customers.map(d => ({ ...d, group: 'customer', val: 5 }))
    ];

    const links = relationships.map(r => ({
        source: r.source,
        target: r.target,
        name: r.label
    }));

    return { nodes, links };
}
