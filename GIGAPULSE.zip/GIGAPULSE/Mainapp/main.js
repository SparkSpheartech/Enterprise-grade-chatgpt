const graphData = getGraphData();

const Graph = ForceGraph()
    (document.getElementById('graph'))
    .graphData(graphData)
    .nodeLabel('label')
    .nodeColor(node => {
        switch (node.group) {
            case 'outage': return '#ff5252';
            case 'customer': return '#448aff';
            case 'infra': return '#ffab40';
            case 'crew': return '#69f0ae';
            case 'noc': return '#e040fb';
            case 'equipment': return '#ab47bc';
            case 'timeline': return '#9e9e9e';
            case 'agent': return '#26a69a';
            case 'construction': return '#8d6e63';
            case 'facility': return '#ffd740';
            case 'interaction': return '#b0bec5';
            default: return '#ffffff';
        }
    })
    .nodeRelSize(6)
    .linkColor(() => 'rgba(255,255,255,0.2)')
    .linkWidth(1)
    .linkDirectionalParticles(2)
    .linkDirectionalParticleSpeed(0.005)
    .backgroundColor('#0b0b0b')
    .onNodeClick(node => {
        showDetails(node);

        // Center camera on node
        Graph.centerAt(node.x, node.y, 1000);
        Graph.zoom(3, 2000);
    })
    .onBackgroundClick(() => {
        hideDetails();
    });

// UI Logic
const sidebar = document.getElementById('sidebar');
const sidebarContent = document.getElementById('sidebar-content');
const closeBtn = document.getElementById('close-sidebar');
const searchInput = document.getElementById('search');

closeBtn.addEventListener('click', hideDetails);

function showDetails(node) {
    sidebar.classList.remove('hidden');

    let content = `
        <div class="detail-header">
            <div class="detail-type">${node.type}</div>
            <h2 class="detail-title">${node.label}</h2>
        </div>
        <div class="detail-body">
            <div class="detail-row">
                <span class="detail-label">ID</span>
                <span class="detail-value">${node.id}</span>
            </div>
    `;

    // Dynamic fields based on node type
    if (node.group === 'outage') {
        content += `
            <div class="detail-row">
                <span class="detail-label">Status</span>
                <span class="detail-value"><span class="tag" style="background: #4caf50">${node.status}</span></span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Impact</span>
                <span class="detail-value">${node.customers} Customers</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Duration</span>
                <span class="detail-value">${node.duration}</span>
            </div>
        `;
    } else if (node.group === 'infra') {
        content += `
            <div class="detail-row">
                <span class="detail-label">Status</span>
                <span class="detail-value" style="color: #ff5252">${node.status}</span>
            </div>
        `;
        if (node.capacity) {
            content += `
                <div class="detail-row">
                    <span class="detail-label">Capacity</span>
                    <span class="detail-value">${node.capacity}</span>
                </div>
            `;
        }
    } else if (node.group === 'crew') {
        content += `
            <div class="detail-row">
                <span class="detail-label">Team Size</span>
                <span class="detail-value">${node.size} Technicians</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Current Task</span>
                <span class="detail-value">${node.task}</span>
            </div>
        `;
    } else if (node.group === 'construction') {
        content += `
            <div class="detail-row">
                <span class="detail-label">Liability</span>
                <span class="detail-value" style="color: #ff5252">${node.liability}</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Est. Cost</span>
                <span class="detail-value">${node.cost}</span>
            </div>
        `;
    } else if (node.group === 'timeline') {
        content += `
            <div class="detail-row">
                <span class="detail-label">Description</span>
                <span class="detail-value">${node.description}</span>
            </div>
        `;
    } else if (node.group === 'equipment') {
        content += `
            <div class="detail-row">
                <span class="detail-label">Location</span>
                <span class="detail-value">${node.location}</span>
            </div>
        `;
    } else if (node.group === 'agent') {
        content += `
            <div class="detail-row">
                <span class="detail-label">Role</span>
                <span class="detail-value">${node.role}</span>
            </div>
        `;
    } else if (node.group === 'facility') {
        content += `
            <div class="detail-row">
                <span class="detail-label">Status</span>
                <span class="detail-value" style="color: #ff5252">${node.status}</span>
            </div>
        `;
    } else if (node.group === 'interaction') {
        content += `
            <div class="detail-row">
                <span class="detail-label">Channel</span>
                <span class="detail-value">${node.channel}</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">NPS Score</span>
                <span class="detail-value">${node.nps}</span>
            </div>
        `;
    }

    content += `</div>`;
    sidebarContent.innerHTML = content;
}

function hideDetails() {
    sidebar.classList.add('hidden');
    Graph.zoomToFit(1000); // Reset zoom when closing
}

// Search Functionality
searchInput.addEventListener('input', (e) => {
    const value = e.target.value.toLowerCase();
    if (!value) return;

    const matchingNode = graphData.nodes.find(n =>
        n.label.toLowerCase().includes(value) ||
        n.id.toLowerCase().includes(value)
    );

    if (matchingNode) {
        Graph.centerAt(matchingNode.x, matchingNode.y, 1000);
        Graph.zoom(4, 2000);
        showDetails(matchingNode);
    }
});

// Initial Zoom
setTimeout(() => {
    Graph.zoomToFit(1000, 50);
}, 500);
